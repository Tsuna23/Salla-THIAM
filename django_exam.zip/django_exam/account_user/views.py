from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from django.contrib.auth import login, logout
from task_manager.views import dashboardEtudiant, dashboardProfesseur
from .models import Utilisateur
from django.contrib import messages

def register(request):
    if request.method == "POST":
        nom = request.POST["nom"]
        email = request.POST["email"]
        password = request.POST["password"]
        role = request.POST["role"] 

        if Utilisateur.objects.filter(nom=nom).exists():
            messages.error(request, "Ce nom d'utilisateur est déjà pris.")
            return redirect("register")

  
        hashed_password = make_password(password)  
        user = Utilisateur(nom=nom, email=email, password=hashed_password, role=role)
        user.save()  

        messages.success(request, "Inscription réussie ! Connecte-toi maintenant.")
        return redirect("login")  

    return render(request, "account_user/register.html")


def login_view(request):
    if request.method == "POST":
        nom = request.POST["nom"]
        password = request.POST["password"]

        try:
            user = Utilisateur.objects.get(nom=nom)
            if user.check_password(password):
                login(request, user)
                messages.success(request, "Connexion réussie.")

               
                if user.role == "professeur":
                    return redirect("dashboard_professeur")#pour le moment je l'ai pas
                else:
                    return redirect("dashboard_etudiant")

            else:
                messages.error(request, "Mot de passe incorrect.")
        except Utilisateur.DoesNotExist:
            messages.error(request, "Utilisateur introuvable.")

    return render(request, "account_user/login.html")


def logout_view(request):
    logout(request)  
    return redirect("accueil")  
