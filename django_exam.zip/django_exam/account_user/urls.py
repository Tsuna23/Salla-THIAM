# Dans account_user/urls.py
from django.urls import path
from .views import register, login_view, logout_view
from task_manager.views import dashboardEtudiant, dashboardProfesseur

urlpatterns = [
    path("register/", register, name="register"),
    path("login/", login_view, name="login"),
    path("logout/", logout_view, name="logout"),

    # Ajout des URLs pour les dashboards
    path("dashboard/etudiant/", dashboardEtudiant, name="dashboard_etudiant"),
    path("dashboard/professeur/", dashboardProfesseur, name="dashboard_professeur"),
]
