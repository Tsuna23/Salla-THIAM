from urllib import request
from django.shortcuts import get_object_or_404, redirect, render
from task_manager.forms import ProjetForm, TacheForm
from task_manager.models import Projet, Tache
# Exemple de vue pour afficher le dashboard avec la top bar
def dashboardEtudiant(request):
    return render(request, "task_manager/dashboard_etudiant.html")
def dashboardProfesseur(request):
    projets = Projet.objects.filter(professeur=request.user)

    return render(request, "task_manager/dashboard_professeur.html", {'projets': projets})

def ajouter_projet(request):
    if request.user.role != 'professeur':
        return redirect('dashboard_etudiant')  # Redirige l'utilisateur vers le dashboard étudiant si ce n'est pas un professeur

    if request.method == 'POST':
        form = ProjetForm(request.POST)
        if form.is_valid():
            projet = form.save(commit=False)
            projet.professeur = request.user  # Associer le projet au professeur connecté
            projet.save()
            return redirect('dashboard_professeur')  # Redirige vers le dashboard du professeur après l'ajout
    else:
        form = ProjetForm()

    return render(request, 'task_manager/ajouter_projet.html', {'form': form})

def ajouter_tache(request, projet_id):
    projet = get_object_or_404(Projet, id=projet_id)

    # Vérifier que l'utilisateur est bien le professeur du projet
    if projet.professeur != request.user:
        return redirect('dashboard_etudiant')  # ou un message d'erreur

    if request.method == 'POST':
        form = TacheForm(request.POST)
        if form.is_valid():
            tache = form.save(commit=False)
            tache.projet = projet
            tache.save()
            return redirect('dashboard_professeur')
    else:
        form = TacheForm()

    return render(request, 'task_manager/ajouter_tache.html', {
        'form': form,
        'projet': projet
    })