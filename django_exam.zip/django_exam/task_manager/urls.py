from django.urls import path
from . import views

urlpatterns = [
    path('dashboard_etudiant/', views.dashboardEtudiant, name='dashboard_etudiant'),
    path('dashboard_professeur/', views.dashboardProfesseur, name='dashboard_professeur'),
    path('ajouter-projet/', views.ajouter_projet, name='ajouter_projet'),
    path('ajouter-tache/<int:projet_id>/', views.ajouter_tache, name='ajouter_tache'),
   
]
