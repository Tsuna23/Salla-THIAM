from django.shortcuts import render

def accueil(request):
    return render(request, 'accueil.html')  # Assure-toi que le fichier est à la racine de 'templates'
